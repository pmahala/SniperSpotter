﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class CameraMovement : MonoBehaviour
{
    private GameManager _gm;
    private DialogGenerator _dg;
    [SerializeField]
    private AudioClip SniperFire;

    public bool phase1 = false;
    public bool phase2 = false;
    public bool phase3 = false;
    // Start is called before the first frame update
    void Start()
    {
        _gm = GameObject.Find("GameManager").GetComponent<GameManager>();
        _dg = GameObject.Find("Spotter").GetComponent<DialogGenerator>();
        
    }

    // Update is called once per frame
    void Update()
    {
        //Debug.Log(Camera.main.ScreenToWorldPoint(Input.mousePosition));

        ScopeMovement();
        WhosBeingHit();

    }

    private void ScopeMovement()
    {
        if (transform.position.x >= -7.4f && transform.position.x <= 7.4f && transform.position.y <= 2.66f && transform.position.y >= -2.66f)
        {
            transform.Translate(new Vector3(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical"), 0f) * Time.deltaTime);
            float temp;
            if(Input.GetAxis("Horizontal")!= 0)
            {
                
                temp = Random.Range(3.0f, 7.0f);
                _gm.SetMil(temp);

            }
            if(Input.GetAxis("Vertical") > 0)
            {
                temp = _gm.GetMil() + 0.01f;
                _gm.SetMil(temp);
            }
            else if(Input.GetAxis("Vertical") < 0)
            {
                temp = _gm.GetMil() - 0.01f;
                _gm.SetMil(temp);
            }
        }
        else if (transform.position.x < -7.4f)
        {
            transform.position = new Vector3(-7.4f, transform.position.y, -10f);
        }
        else if (transform.position.x > 7.4f)
        {
            transform.position = new Vector3(7.4f, transform.position.y, -10f);
        }
        else if (transform.position.y > 2.66f)
        {
            transform.position = new Vector3(transform.position.x, 2.66f, -10f);
        }
        else if (transform.position.y < -2.66f)
        {
            transform.position = new Vector3(transform.position.x, -2.66f, -10f);
        }
    }

    private void WhosBeingHit()
    {
        RaycastHit2D hit = Physics2D.Raycast(Camera.main.transform.position, -Vector2.up);
        if(hit.collider.gameObject != null)
        {
            if(hit.collider.gameObject == _gm.MarkerSelected() && phase1)
            {
                _dg.awaitingSniper1 = true;
                phase1 = false;
            }
            if(hit.collider.gameObject == _gm.TargetToShoot() && phase2)
            {
                _dg.awaitingSniper2 = true;
                phase2 = false;
            }
            if (hit.collider.gameObject == _gm.TargetToShoot() && phase3)
            {
                if(Input.GetKeyDown(KeyCode.Space))
                {
                    AudioSource.PlayClipAtPoint(SniperFire,Camera.main.transform.position);
                    Destroy(hit.collider.gameObject);
                    phase1 = false;
                    phase2 = false;
                    phase3 = false;
                    _dg.newTarget = true;
                    _dg.awaitingSniper1 = false;
                    _dg.awaitingSniper2 = false;
                }
            }
        }
        
    }
}

