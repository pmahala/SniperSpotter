﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DisplayMil : MonoBehaviour
{
    private GameManager _gm;
    [SerializeField]
    private Text milDisplay;
    // Start is called before the first frame update
    void Start()
    {
        _gm = GameObject.Find("GameManager").GetComponent<GameManager>();
    }

    // Update is called once per frame
    void Update()
    {
        Display();

    }

    private void Display()
    {
        float temp = _gm.GetMil();
        milDisplay.text = temp.ToString();
    }
}
