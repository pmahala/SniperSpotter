﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class DialogGenerator : MonoBehaviour
{
    [SerializeField]
    private Text Spotter;
    [SerializeField]
    private Text Sniper;

    private CameraMovement _cm;

    private GameManager _gm;
    public bool newTarget = true;
    public bool awaitingSniper1 = false;
    public bool awaitingSniper2 = false;
    // Start is called before the first frame update
    void Start()
    {
        _gm = GameObject.Find("GameManager").GetComponent<GameManager>();
        _cm = Camera.main.GetComponent<CameraMovement>();

    }

    // Update is called once per frame
    void Update()
    {
        if(newTarget)
        {
            Spotter.text = "Go to " + _gm.MarkerSelected().name;
            if (Input.GetKeyDown(KeyCode.Space))
            {
                Sniper.text = "";
                newTarget = false;
                _cm.phase1 = true;
            }
                
        }
        if(awaitingSniper1)
        {
            float leftclicks = _gm.TargetToShoot().transform.position.x - _gm.MarkerSelected().transform.position.x;
            float elevation = _gm.TargetToShoot().transform.position.y - _gm.MarkerSelected().transform.position.y;
            Spotter.text = "Go " + leftclicks + "clicks laterally and " + elevation + " clicks vertically";
            if(Input.GetKeyDown(KeyCode.Space))
            {
                Sniper.text = "";
                awaitingSniper1 = false;
                _cm.phase2 = true;
            }
            
        }
        else if(awaitingSniper2)
        {
            Spotter.text = "Thats the target!!! Take the shot!!!";
            if(Input.GetKeyDown(KeyCode.Space))
            {
                Sniper.text = "";
                awaitingSniper2 = false;
                _cm.phase3 = true;
            }
            
        }
        
    }
}
