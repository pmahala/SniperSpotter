﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{

    private float mil;

    [SerializeField]
    private GameObject[] Markers;

    private GameObject SelectedMarker;

    private GameObject CurrentTarget;

    [SerializeField]
    private GameObject _TargetPrefab;




    private void Update()
    {
        GenerateTarget();
    }

    public float GetMil()
    {
        return mil;
    }
    public void SetMil(float f)
    {
        mil = f;
    }

    
    public void GenerateTarget()
    {
        if (!GameObject.FindGameObjectWithTag("Target"))
        {
            
            SelectedMarker = Markers[Random.Range(0, 3)];
            Debug.Log("Selected MArker " + SelectedMarker);
            if(SelectedMarker.name == "MarkerB")
            {
                CurrentTarget = Instantiate(_TargetPrefab, SelectedMarker.transform.position + new Vector3(Random.Range(-2.0f, 2.0f), Random.Range(-1.0f, -2.0f), 0f), Quaternion.identity);
            }
            else if(SelectedMarker.name == "MarkerA")
            {
                CurrentTarget = Instantiate(_TargetPrefab, SelectedMarker.transform.position + new Vector3(Random.Range(0.0f, 2.0f), Random.Range(-1.0f, -2.0f), 0f), Quaternion.identity);
            }
            else if(SelectedMarker.name == "MarkerC")
            {
                CurrentTarget = Instantiate(_TargetPrefab, SelectedMarker.transform.position + new Vector3(Random.Range(-2.0f, 0.0f), Random.Range(-1.0f, -2.0f), 0f), Quaternion.identity);
            }
        }
    }

    public GameObject MarkerSelected()
    {
        return SelectedMarker;
    }

    public GameObject TargetToShoot()
    {
        return CurrentTarget;
    }
    



}
